<?php
declare(strict_types=1);
// Contains no password. Reuse the already configured, protected CSV database.
$source=dirname(__DIR__,2).'/ekwl-staging/backend/config/config.local.php';
if(!is_file($source))throw new RuntimeException('Existing MySQL configuration is unavailable.');
$c=require $source;
if(!is_array($c)||!preg_match('/(?:^|;)dbname=if0_43242550_ekwl_stage(?:;|$)/',$c['dsn']??''))throw new RuntimeException('Expected CSV database is not configured.');
return array_replace($c,[
    'environment'=>'production',
    'origin'=>'https://littleboy.kesug.com',
    'base_path'=>'/',
    'session_name'=>'EKWL_LIVE_SESSION',
    'secure_cookies'=>true,
    'allow_archive_cleanup'=>false,
]);
